#!/bin/bash

#print the content of file 
#./hw1.sh filenam filename2

cat $@

